package com.codewithkeshav.teachertrack

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.codewithkeshav.teachertrack.R

class DashboardActivityHod : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dashboard_hod)
    }
}
